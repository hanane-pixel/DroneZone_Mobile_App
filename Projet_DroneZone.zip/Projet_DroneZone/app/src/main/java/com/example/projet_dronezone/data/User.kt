package com.example.projet_dronezone.data

data class User(
    val id: Int = 0,
    val name: String = "",
    val email: String = "",
    val password: String = ""
)