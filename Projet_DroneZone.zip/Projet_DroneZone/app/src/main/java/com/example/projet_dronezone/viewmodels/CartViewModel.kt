package com.example.projet_dronezone.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import com.example.projet_dronezone.data.CartItem
import com.example.projet_dronezone.data.Product
import com.example.projet_dronezone.data.ProductDataSource

class CartViewModel : ViewModel() {
    private val _cartItems = MutableStateFlow<List<CartItem>>(emptyList())
    val cartItems: StateFlow<List<CartItem>> = _cartItems

    init {
        loadSampleCartItems()
    }

    private fun loadSampleCartItems() {
        viewModelScope.launch {
            val products = ProductDataSource().loadProducts()
            val sampleItems = listOf(
                CartItem(products[0], 1),
                CartItem(products[1], 1),
                CartItem(products[2], 1),
                CartItem(products[5], 1)
            )
            _cartItems.value = sampleItems
        }
    }

    val subtotal: Double
        get() = _cartItems.value.sumOf { it.product.price * it.quantity }

    val taxes: Double
        get() = 438.0

    val total: Double
        get() = subtotal + taxes

    fun addToCart(product: Product) {
        viewModelScope.launch {
            val currentItems = _cartItems.value.toMutableList()
            val existingItem = currentItems.find { it.product.id == product.id }

            if (existingItem != null) {
                val updatedItem = existingItem.copy(quantity = existingItem.quantity + 1)
                currentItems[currentItems.indexOf(existingItem)] = updatedItem
            } else {
                currentItems.add(CartItem(product = product, quantity = 1))
            }

            _cartItems.value = currentItems
        }
    }

    fun removeFromCart(cartItem: CartItem) {
        viewModelScope.launch {
            val currentItems = _cartItems.value.toMutableList()
            currentItems.remove(cartItem)
            _cartItems.value = currentItems
        }
    }

    fun clearCart() {
        viewModelScope.launch {
            _cartItems.value = emptyList()
        }
    }
}