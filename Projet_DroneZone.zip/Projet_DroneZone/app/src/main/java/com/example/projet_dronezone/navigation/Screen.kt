package com.example.projet_dronezone.navigation

sealed class Screen(val route: String) {
    object Welcome : Screen("welcome")
    object Login : Screen("login")
    object SignUp : Screen("signup")
    object ProductList : Screen("product_list")
    object ProductDetail : Screen("product_detail")
    object Cart : Screen("cart")
    object CheckoutSuccess : Screen("checkout_success")
    object OrderError : Screen("order_error")
    object Profile : Screen("profile")
}