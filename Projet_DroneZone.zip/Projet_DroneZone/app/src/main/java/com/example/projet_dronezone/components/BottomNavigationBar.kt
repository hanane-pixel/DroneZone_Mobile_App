package com.example.projet_dronezone.components

import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ShoppingCart
import androidx.compose.material3.Icon
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import androidx.navigation.compose.currentBackStackEntryAsState
import com.example.projet_dronezone.navigation.Screen

sealed class BottomNavItem(val route: String, val icon: ImageVector, val label: String) {
    object Home : BottomNavItem(Screen.Welcome.route, Icons.Default.Home, "Home")
    object Products : BottomNavItem(Screen.ProductList.route, Icons.Default.List, "Products")
    object Cart : BottomNavItem(Screen.Cart.route, Icons.Default.ShoppingCart, "Cart")
    object Profile : BottomNavItem(Screen.Profile.route, Icons.Default.Person, "Profile")
}

@Composable
fun BottomNavigationBar(navController: NavController) {

    val SelectedColor = Color.Black
    val UnselectedColor = Color(0xFF2998CC)

    val items = listOf(
        BottomNavItem.Home,
        BottomNavItem.Products,
        BottomNavItem.Cart,
        BottomNavItem.Profile
    )

    val navBackStackEntry by navController.currentBackStackEntryAsState()
    val currentRoute = navBackStackEntry?.destination?.route

    NavigationBar(
        containerColor = Color.White,
        modifier = Modifier.padding(top = 1.dp)
    ) {
        items.forEach { item ->
            val isSelected = currentRoute == item.route

            val isProductDetail = currentRoute?.startsWith(Screen.ProductDetail.route) == true && item.route == Screen.ProductList.route

            val isCurrentlySelected = isSelected || isProductDetail

            NavigationBarItem(
                selected = isCurrentlySelected,
                onClick = {
                    navController.navigate(item.route) {
                        navController.graph.startDestinationRoute?.let { route ->
                            popUpTo(route) { saveState = true }
                        }
                        launchSingleTop = true
                        restoreState = true
                    }
                },
                icon = {
                    Icon(
                        item.icon,
                        contentDescription = item.label,
                        tint = if (isCurrentlySelected) SelectedColor else UnselectedColor
                    )
                },
                label = {
                    Text(
                        item.label,
                        color = if (isCurrentlySelected) SelectedColor else UnselectedColor
                    )
                },
                alwaysShowLabel = true
            )
        }
    }
}