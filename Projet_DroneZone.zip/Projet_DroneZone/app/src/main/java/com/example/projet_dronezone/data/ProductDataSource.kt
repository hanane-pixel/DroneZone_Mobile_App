package com.example.projet_dronezone.data

class ProductDataSource {
    fun loadProducts(): List<Product> {
        return listOf(
            Product(
                id = 1,
                name = "DJI Mavic 3 Pro",
                brand = "DJI Mavic 3 Pro",
                price = 2199.0,
                imageRes = "img_drone_mavic_3_pro",
                description = "Professional drone with Hasselblad camera"
            ),
            Product(
                id = 2,
                name = "DJI Air 2S",
                brand = "DJI Air 2S",
                price = 999.0,
                imageRes = "img_drone_air_3",
                description = "Compact drone with 1-inch sensor"
            ),
            Product(
                id = 3,
                name = "DJI Mini 3 Pro",
                brand = "DJI Mini 3 Pro",
                price = 759.0,
                imageRes = "img_drone_mini_4_pro",
                description = "Ultra-light premium drone"
            ),
            Product(
                id = 4,
                name = "DJI FPV",
                brand = "DJI FPV",
                price = 1299.0,
                imageRes = "img_drone_inspire_3",
                description = "Professional cinema drone"
            ),
            Product(
                id = 5,
                name = "DJI Mavic 3 Classic",
                brand = "DJI",
                price = 1699.0,
                imageRes = "img_drone_mavic_3_classic",
                description = "Professional drone without tele camera"
            ),
            Product(
                id = 6,
                name = "DJI Avata",
                brand = "DJI",
                price = 629.0,
                imageRes = "img_drone_avata",
                description = "FPV drone for immersive flight"
            )
        )
    }
}