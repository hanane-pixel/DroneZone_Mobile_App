package com.example.projet_dronezone.viewmodels

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

data class User(
    val firstName: String,
    val lastName: String,
    val email: String
)

class AuthViewModel : ViewModel() {
    private val _currentUser = MutableStateFlow<User?>(null)
    val currentUser: StateFlow<User?> = _currentUser

    private val _loginError = MutableStateFlow<String?>(null)
    val loginError: StateFlow<String?> = _loginError

    private val _signUpError = MutableStateFlow<String?>(null)
    val signUpError: StateFlow<String?> = _signUpError

    private val _registeredUsers = mutableListOf<User>()

    init {
        viewModelScope.launch {
            _currentUser.value = User(
                firstName = "HANANE",
                lastName = "ELHABAL",
                email = "hanane.elhabal@gmail.com"
            )
        }
    }

    fun login(email: String, password: String): Boolean {
        return if (email.isNotEmpty() && password.isNotEmpty()) {
            viewModelScope.launch {
                val user = _registeredUsers.find { it.email == email }
                    ?: User(
                        firstName = "User",
                        lastName = "Default",
                        email = email
                    )

                _currentUser.value = user
                _loginError.value = null
            }
            true
        } else {
            _loginError.value = "Please enter email and password"
            false
        }
    }

    fun signUp(name: String, email: String, password: String): Boolean {
        return if (name.isNotEmpty() && email.isNotEmpty() && password.isNotEmpty()) {
            viewModelScope.launch {
                val nameParts = name.split(" ").filter { it.isNotBlank() }
                val firstName = nameParts.firstOrNull() ?: ""
                val lastName = nameParts.drop(1).joinToString(" ") ?: ""

                val newUser = User(
                    firstName = firstName,
                    lastName = if (lastName.isEmpty()) "User" else lastName,
                    email = email
                )

                _registeredUsers.add(newUser)
                _currentUser.value = newUser
                _signUpError.value = null
            }
            true
        } else {
            _signUpError.value = "Please fill all fields"
            false
        }
    }

    fun logout() {
        viewModelScope.launch {
            _currentUser.value = null
            _loginError.value = null
            _signUpError.value = null
        }
    }
}