package com.example.projet_dronezone.data

data class Product(
    val id: Int,
    val name: String,
    val brand: String,
    val price: Double,
    val imageRes: String,
    val description: String = ""
)
