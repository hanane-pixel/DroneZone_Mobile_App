// Fichier : com/example/projet_dronezone/getImageResource.kt
package com.example.projet_dronezone

// Import de la classe R de votre projet
import com.example.projet_dronezone.R

fun getImageResource(imageName: String): Int {
    return when (imageName) {
        // ASSUREZ-VOUS QUE CES NOMS CORRESPONDENT AUX FICHIERS DANS res/drawable
        "drone_hero" -> R.drawable.drone_hero
        "img_drone_mavic_3_pro" -> R.drawable.img_drone_mavic_3_pro
        "img_drone_air_3" -> R.drawable.img_drone_air_3
        "img_drone_mini_4_pro" -> R.drawable.img_drone_mini_4_pro
        "img_drone_inspire_3" -> R.drawable.img_drone_inspire_3
        "img_drone_mavic_3_classic" -> R.drawable.img_drone_mavic_3_classic
        "img_drone_avata" -> R.drawable.img_drone_avata
        "img_drone_x100" -> R.drawable.img_drone_x100
        else -> R.drawable.drone_hero // Fallback
    }
}