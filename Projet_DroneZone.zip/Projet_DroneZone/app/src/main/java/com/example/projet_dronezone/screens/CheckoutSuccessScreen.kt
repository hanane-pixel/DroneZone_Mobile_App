package com.example.projet_dronezone.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.outlined.AttachMoney
import androidx.compose.material.icons.outlined.CreditCard
import androidx.compose.material.icons.outlined.LocalShipping
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.projet_dronezone.components.BottomNavigationBar
import com.example.projet_dronezone.navigation.Screen
import com.example.projet_dronezone.R

private val SuccessGreen = Color(0xFF5CB85C)
private val LightGreenIcon = Color(0xFFE6F3E6)
private val PrimaryBlack = Color(0xFF333333)
private val GrayText = Color(0xFF666666)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CheckoutSuccessScreen(navController: NavController) {
    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = "Checkout",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color.White,
                    titleContentColor = Color.Black,
                    navigationIconContentColor = Color.Black
                )
            )
        },
        bottomBar = {
            BottomNavigationBar(navController = navController)
        },
        containerColor = Color.White
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(horizontal = 24.dp),
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 16.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.Center,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "Order Successful!",
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = PrimaryBlack
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Icon(
                        imageVector = Icons.Default.CheckCircle,
                        contentDescription = "Success Checkmark",
                        modifier = Modifier.size(28.dp),
                        tint = SuccessGreen
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "Thank you for your purchase! Your order has been placed and is being processed. You will receive a confirmation email shortly.",
                    fontSize = 14.sp,
                    color = GrayText,
                    lineHeight = 20.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 8.dp)
                )

                Spacer(modifier = Modifier.height(32.dp))

                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.Start
                ) {
                    OrderItemRow(
                        label = "Drone",
                        detail = "DJI Phantom 4 Pro",
                        iconComposable = {
                            Image(
                                painter = painterResource(id = R.drawable.img_drone_x100),
                                contentDescription = "Drone Image",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(8.dp))
                            )
                        },
                        detailColor = SuccessGreen
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    OrderItemRow(
                        label = "Shipping",
                        detail = "Standard Shipping",
                        iconComposable = {
                            IconContainer(icon = Icons.Outlined.LocalShipping)
                        },
                        detailColor = SuccessGreen
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    OrderItemRow(
                        label = "Payment",
                        detail = "Credit Card",
                        iconComposable = {
                            IconContainer(icon = Icons.Outlined.CreditCard)
                        },
                        detailColor = SuccessGreen
                    )

                    Spacer(modifier = Modifier.height(24.dp))

                    OrderItemRow(
                        label = "Total",
                        detail = "$1,499.00",
                        iconComposable = {
                            IconContainer(icon = Icons.Outlined.AttachMoney)
                        },
                        detailColor = SuccessGreen
                    )
                }
            }

            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp)
            ) {
                Button(
                    onClick = {
                        navController.navigate(Screen.ProductList.route) {
                            popUpTo(Screen.ProductList.route) { inclusive = true }
                        }
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(56.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = SuccessGreen
                    ),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Text(
                        "Continue Shopping",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                }
            }
        }
    }
}

@Composable
private fun IconContainer(icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(RoundedCornerShape(8.dp))
            .background(LightGreenIcon)
    ) {
        Icon(
            imageVector = icon,
            contentDescription = null,
            tint = SuccessGreen,
            modifier = Modifier
                .size(24.dp)
                .align(Alignment.Center)
        )
    }
}

@Composable
private fun OrderItemRow(
    label: String,
    detail: String,
    iconComposable: @Composable () -> Unit,
    detailColor: Color
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        iconComposable()

        Spacer(modifier = Modifier.width(19.dp))

        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = label,
                fontSize = 19.sp,
                fontWeight = FontWeight.SemiBold,
                color = PrimaryBlack
            )
            Text(
                text = detail,
                fontSize = 17.sp,
                color = detailColor,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun CheckoutSuccessScreenPreview() {
    Surface {
        CheckoutSuccessScreen(navController = rememberNavController())
    }
}