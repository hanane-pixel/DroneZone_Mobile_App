package com.example.projet_dronezone.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.projet_dronezone.components.BottomNavigationBar
import com.example.projet_dronezone.data.CartItem
import com.example.projet_dronezone.data.ProductDataSource
import com.example.projet_dronezone.getImageResource
import com.example.projet_dronezone.navigation.Screen
import com.example.projet_dronezone.viewmodels.CartViewModel
import java.util.Locale
import kotlin.random.Random

private val PrimaryBlue = Color(0xFF2998CC)
private val GrayText = Color(0xFF666666)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CartScreen(navController: NavController) {
    val cartViewModel: CartViewModel = viewModel()
    val cartItems = cartViewModel.cartItems.collectAsState().value

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = {
                    Text(
                        text = "Cart",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                },
                navigationIcon = {
                    IconButton(onClick = { navController.popBackStack() }) {
                        Icon(Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color.White,
                    titleContentColor = Color.Black,
                    navigationIconContentColor = Color.Black
                )
            )
        },
        bottomBar = {
            BottomNavigationBar(navController = navController)
        },
        containerColor = Color.White
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(Color.White)
        ) {
            if (cartItems.isEmpty()) {
                EmptyCartState()
            } else {
                CartWithItems(cartViewModel, cartItems, navController)
            }
        }
    }
}

@Composable
fun CartWithItems(
    cartViewModel: CartViewModel,
    cartItems: List<CartItem>,
    navController: NavController
) {
    Column(
        modifier = Modifier.fillMaxSize()
    ) {
        LazyColumn(
            modifier = Modifier
                .weight(1f),
            contentPadding = PaddingValues(top = 16.dp, start = 24.dp, end = 24.dp)
        ) {
            items(cartItems, key = { it.product.id }) { cartItem ->
                CartItemRow(cartItem = cartItem)
                Spacer(modifier = Modifier.height(16.dp))
            }
            item {
                Spacer(modifier = Modifier.height(15.dp))
                OrderSummary(cartViewModel)
                Spacer(modifier = Modifier.height(24.dp))
            }
        }

        Button(
            onClick = {
                val showSuccess = Random.nextBoolean()
                if (showSuccess) {
                    navController.navigate(Screen.CheckoutSuccess.route)
                } else {
                    navController.navigate(Screen.OrderError.route)
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp)
                .padding(horizontal = 24.dp)
                .padding(bottom = 16.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = PrimaryBlue
            ),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text(
                text = "Checkout",
                fontSize = 18.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
    }
}

@Composable
fun CartItemRow(cartItem: CartItem) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Image(
            painter = painterResource(id = getImageResource(cartItem.product.imageRes)),
            contentDescription = cartItem.product.name,
            contentScale = ContentScale.Crop,
            modifier = Modifier
                .size(70.dp)
                .clip(RoundedCornerShape(8.dp))
        )

        Spacer(modifier = Modifier.width(16.dp))

        Column(
            modifier = Modifier.weight(1f)
        ) {
            Text(
                text = cartItem.product.name,
                fontSize = 16.sp,
                fontWeight = FontWeight.SemiBold,
                color = Color.Black
            )

            Text(
                text = cartItem.product.brand,
                fontSize = 14.sp,
                color = PrimaryBlue,
                modifier = Modifier.padding(top = 2.dp)
            )
        }

        Text(
            text = "$${String.format(Locale.US, "%,.0f", cartItem.product.price)}",
            fontSize = 16.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color.Black
        )
    }
}

@Composable
fun OrderSummary(cartViewModel: CartViewModel) {
    val subtotal = cartViewModel.subtotal
    val taxes = cartViewModel.taxes
    val total = cartViewModel.total

    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
    ) {

        OrderSummaryRow(
            label = "Subtotal",
            value = "$${String.format(Locale.US, "%,.0f", subtotal)}",
            labelColor = GrayText
        )

        Spacer(modifier = Modifier.height(16.dp))

        OrderSummaryRow(
            label = "Shipping",
            value = "Free",
            labelColor = GrayText
        )

        Spacer(modifier = Modifier.height(16.dp))

        OrderSummaryRow(
            label = "Taxes",
            value = "$${String.format(Locale.US, "%,.0f", taxes)}",
            labelColor = GrayText
        )

        Spacer(modifier = Modifier.height(24.dp))

        OrderSummaryRow(
            label = "Total",
            value = "$${String.format(Locale.US, "%,.0f", total)}",
            isTotal = true
        )
    }
}

@Composable
fun OrderSummaryRow(label: String, value: String, isTotal: Boolean = false, labelColor: Color = Color.Black) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {

        Text(
            text = label,
            fontSize = 16.sp,
            fontWeight = if (isTotal) FontWeight.Bold else FontWeight.Normal,
            color = if (isTotal) Color.Black else labelColor
        )

        Text(
            text = value,
            fontSize = 16.sp,
            fontWeight = if (isTotal) FontWeight.Bold else FontWeight.SemiBold,
            color = Color.Black
        )
    }
}

@Composable
fun EmptyCartState() {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(32.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Your cart is empty",
            fontSize = 18.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Gray,
            modifier = Modifier.padding(bottom = 8.dp)
        )
        Text(
            text = "Add some drones to get started!",
            fontSize = 14.sp,
            color = Color.Gray
        )
    }
}

@Preview(showBackground = true)
@Composable
fun CartScreenPreview() {
    val mockProducts = ProductDataSource().loadProducts()
        .filter { it.id in 1..4 }
    val mockCartItems = mockProducts.map { CartItem(product = it, quantity = 1) }

    Surface {
        Column(modifier = Modifier.fillMaxSize().background(Color.White)) {
            CartWithItems(
                cartViewModel = viewModel(),
                cartItems = mockCartItems,
                navController = rememberNavController()
            )
        }
    }
}